import { setupUI } from './ui'

setupUI()