#pragma once

namespace komunikacja {void final();}

