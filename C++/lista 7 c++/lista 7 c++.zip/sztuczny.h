
#pragma once
#include <string>
#include <vector>

namespace sztuczny {int sztuczna(vector<string> tablica , int rozmiar);}

