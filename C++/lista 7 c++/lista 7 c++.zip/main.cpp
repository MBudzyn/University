#include <iostream>
#include "Stangry.h"
#include "komunikacja.h"
#include "sztuczny.h"

    int main()
    {
    komunikacja::final();
        return 0;
    }
