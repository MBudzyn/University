
#include "Wyjdziel0.h"
Wyjdziel0::Wyjdziel0(const std::string &what_arg)  : WyjWym(what_arg){}