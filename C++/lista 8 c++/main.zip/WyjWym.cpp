#include "WyjWym.h"

WyjWym::WyjWym(const std::string& what_arg) : logic_error(what_arg){}