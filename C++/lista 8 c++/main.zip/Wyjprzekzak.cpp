
#include "Wyjprzekzak.h"

Wyjprzekzak::Wyjprzekzak(const std::string &what_arg): WyjWym(what_arg){}