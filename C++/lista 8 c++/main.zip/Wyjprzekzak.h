#pragma once
#include "WyjWym.h"

class Wyjprzekzak : public WyjWym{
public:
    explicit Wyjprzekzak(const std::string& what_arg);

};