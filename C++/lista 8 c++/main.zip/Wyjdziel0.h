#include "WyjWym.h"
#pragma once

class Wyjdziel0 : public WyjWym{
public:
    explicit Wyjdziel0(const std::string& what_arg);

};

